import os
import pandas as pd
from flask import Flask, request, jsonify, Response
from flask_mysqldb import MySQL
from flask_cors import CORS
import MySQLdb.cursors
from werkzeug.serving import WSGIRequestHandler
from werkzeug.utils import secure_filename

app = Flask(__name__, static_folder="static")
WSGIRequestHandler.protocol_version = "HTTP/1.1"

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'school'
app.secret_key = 'charity'

CORS(app)
mysql = MySQL(app)



@app.route('/api/setStudents/', methods=['POST'])
def set_candidate():
    if request.method == 'POST':
        data = request.files['data']
        df = pd.read_csv(data)
        email = request.form['email']
        _name = request.form['name']
        act_name = _name
        _name = _name.replace(" ","_").lower()
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("select * from class where class_name='{0}'".format(act_name))
        exam = cursor.fetchall()
        if len(exam) == 0 and len(df) > 0:
            try:
                cursor.execute('create table {0}(email varchar(150) primary key,name text not null,'
                               'password text not null,stat text not null,phone text not null unique,address text not null)'.format(_name))
                cursor.execute("insert into class(class_name,created_user) values(%s,%s)", (act_name, email))
                mysql.connection.commit()
                for index, row in df.iterrows():
                    name = row['name']
                    email = row['email']
                    address = row['address']
                    phone = row['phone']
                    password = row['password']
                    print(name, email, password)
                    cursor.execute("INSERT INTO {}(name, email, password,stat,phone,address) VALUES ('{}', '{}','{}','n','{}','{}')"
                                   .format(_name, name, email, password,phone,address))
                    mysql.connection.commit()
                return jsonify(status="success")
            except MySQLdb.MySQLError:
                return jsonify(
                    status="Error"
                )

        else:
            return jsonify(status="Class already Exist try some other name or File is empty")
    else:
        return jsonify(
            status="Error"
        )


@app.route('/api/getVideos/', methods=['POST'])
def get_question():
    if request.method == 'POST' and 'class' in request.form:
        name = request.form['class']
        print(name)
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT class_id FROM class WHERE class_name = %s',
                       (name,))
        class_id = cursor.fetchone()
        print(class_id)
        class_id = class_id['class_id']
        print(class_id)
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM videos where class_id = {0}'.format(class_id))
        videos = cursor.fetchall()
        if videos is not None:
            return jsonify(videos)
        else:
            return jsonify(
                status='No Data',
            )
    else:
        return jsonify(
            status='Error'
        )



@app.route('/api/register/', methods=['POST'])
def register():
    if request.method == "POST" and 'email' in request.form:
        email = request.form['email']
        name = request.form['name']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        try:
            cursor.execute("insert into teachers(name,email,password) values(%s,%s,%s)", (name, email, password))
            mysql.connection.commit()
            return jsonify(
                status="success"
            )
        except MySQLdb.IntegrityError:
            return jsonify(
                status="Error"
            )
    else:
        return jsonify(status="Error")


@app.route('/api/login/', methods=['POST'])
def login():
    if request.method == "POST" and 'email' in request.form:
        email = request.form['email']
        password = request.form['password']
        table = request.form['type']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("select * from {} where email = '{}' and password = '{}'".format(table,email, password))
        user = cursor.fetchall()
        if len(user) > 0:
            return jsonify(status="success")
        else:
            return jsonify(status="invalid")
    else:
        return jsonify(status="Error")

@app.route('/api/class/', methods=['POST'])
def get_classes():
    if request.method == "POST":
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("select class_name from class")
        data = cursor.fetchall()
        return jsonify(data)
    else:
        return jsonify([])


@app.route('/api/upload/', methods=['POST'])
def upload():
    if request.method == "POST":
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        file = request.files['file']
        class_name = request.form['name']
        title = request.form['title']
        desc = request.form['desc']
        fname = secure_filename(file.filename)
        try:
            os.mkdir(os.path.join('./static/files/', class_name.lower()))
        except FileExistsError:
            print("Location Exists")
        file.save(os.path.join('./static/files/' + class_name.lower()+"/", fname))
        cursor.execute("select class_id from class where class_name = '{}'".format(class_name))
        _id = cursor.fetchone()
        _id = _id['class_id']
        cursor.execute("insert into videos(video,class_id,title,description) values(%s,%s,%s,%s)",(fname,_id,title,desc))
        mysql.connection.commit()
        return jsonify(status="success")


@app.route('/api/slogin/', methods=['POST'])
def login_c():
    if request.method == "POST" and 'email' in request.form:
        email = request.form['email']
        password = request.form['password']
        table = request.form["class"]
        table = table.lower()
        table = table.replace(" ", "_")
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

        try:
            cursor.execute(
                "select * from {0} where email = '{1}' and password = '{2}' and stat='n'".format(table, email,
                                                                                                 password))
            user = cursor.fetchall()
            print(user)
            if len(user) > 0:
                return jsonify(status="success")
            else:
                return jsonify(status="invalid")
        except:
            return jsonify(
                status="Error"
            )
    else:
        return jsonify(status="Error")


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
