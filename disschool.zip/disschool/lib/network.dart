import 'package:dio/dio.dart';

Future<String> register(String name, String email, String password) async {
  var res = await Dio().post("http://127.0.0.1:5000/api/register/",
      data: FormData.fromMap(
          {"email": email, "name": name, "password": password}));

  return res.data["status"];
}

Future<String> login(String email, String password,type) async {
  var res = await Dio().post("http://127.0.0.1:5000/api/login/",
      data: FormData.fromMap({"email": email, "password": password,"type":type}));
  print(res.data);
  return res.data["status"];
}