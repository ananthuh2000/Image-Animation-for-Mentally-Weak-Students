import 'package:disschool/network.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'students/register.dart';
import 'teachers/home.dart';
class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final formKey = GlobalKey<FormState>();
  final emailController = TextEditingController();
  final passController = TextEditingController();
  @override
  void dispose()
  {
    emailController.dispose();
    passController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
           const Text("Login",style: TextStyle(fontSize: 40,fontWeight: FontWeight.bold),),
           Container(
            margin:const EdgeInsets.fromLTRB(0, 40, 0, 0),
            width: 500,
            child: Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  
                  TextFormField(
                    controller: emailController,
                    decoration:const InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Email")
                    ),
                    validator: (value) {
                      if(value == "")
                      {
                        return "Enter valid email";
                      }
                      else
                      {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    controller: passController,
                    obscureText: true,
                    decoration:const InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Password")
                    ),
                    validator: (value) {
                      if(value == "")
                      {
                        return "Enter valid password";
                      }
                      else
                      {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  ElevatedButton(onPressed:()async{
                    if(formKey.currentState!.validate())
                    {
                      String status = await login(emailController.text, passController.text,"teachers");
                      if(status == "success") {
                        SharedPreferences pref = await SharedPreferences.getInstance();
                        pref.setString("email", emailController.text);
                        Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>DashBoardPage()));
                      } else {
                        print("Err");
                      }
                    }
                  },
                  child: const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text("Login",style: TextStyle(fontSize: 24),),
                  )),
                  const SizedBox(
                    height: 10,
                  ),
                  TextButton(onPressed: (){
                    Navigator.push(context,MaterialPageRoute(builder: (context)=>Register()));
                  },
                  
                  child: const Text("Don't have Account? Click here..", style: TextStyle(color: Colors.red))),
                  // TextButton(onPressed: (){
                  //   Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>TeacherLogin()));
                  // },
                  
                  // child: const Text("Teacher Login here..", style: TextStyle(color: Colors.red)))
                ],
              ),
            ),
           )
          ],
        ),
      ),
    );
  }
}