import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UploadScreen extends StatefulWidget {
  const UploadScreen({super.key});

  @override
  State<UploadScreen> createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  final formKey = GlobalKey<FormState>();
  final titleController = TextEditingController();
  final descController = TextEditingController();
  List<String> _classNames = [];
  String? _selectedclass;
  var _File, _FileName;
  void _fetchclassNames() async {
    try {
      final response = await Dio().post('http://127.0.0.1:5000/api/class/');
      for (var u in response.data) {
        _classNames.add(u["class_name"]);
      }
      setState(() {});
    } catch (e) {
      print(e);
    }
  }

  void _pickFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['mp4', "avi"],
    );
    print(result!.files.first.name);
    if (result != null) {
      setState(() {
        _File = result.files.first.bytes;
        _FileName = result.files.first.name;
      });
    }
    setState(() {});
  }

  @override
  void dispose() {
    titleController.dispose();
    descController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _fetchclassNames();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              margin: const EdgeInsets.fromLTRB(0, 40, 0, 0),
              width: 500,
              child: Form(
                key: formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    TextFormField(
                      controller: titleController,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(), label: Text("Title")),
                      validator: (value) {
                        if (value == "") {
                          return "Enter valid text";
                        } else {
                          return null;
                        }
                      },
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    TextFormField(
                      controller: descController,
                      decoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          label: Text("Description")),
                      validator: (value) {
                        if (value == "") {
                          return "Enter valid text";
                        } else {
                          return null;
                        }
                      },
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    DropdownButtonFormField<String>(
                      value: _selectedclass,
                      decoration: InputDecoration(border: OutlineInputBorder()),
                      hint: Text('Select an class'),
                      validator: (value) {
                        if (value == null) {
                          return "Can't be Empty";
                        }
                        return null;
                      },
                      onChanged: (value) {
                        setState(() {
                          _selectedclass = value;
                        });
                      },
                      items: _classNames.map((className) {
                        return DropdownMenuItem<String>(
                          value: className,
                          child: Text(className),
                        );
                      }).toList(),
                    ),
                    SizedBox(height: 8.0),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            _File != null ? _FileName : 'No file selected',
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        SizedBox(width: 8.0),
                        ElevatedButton(
                          onPressed: _pickFile,
                          child: Text('Select File'),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    ElevatedButton(
                        onPressed: () async {
                          if (formKey.currentState!.validate()) {
                            String status = await upload(titleController.text,
                                descController.text, _selectedclass);
                            Fluttertoast.showToast(msg: status);
                            if (status == "success") {
                              SharedPreferences pref =
                                  await SharedPreferences.getInstance();
                              pref.setString("email", titleController.text);
                              pref.setString("class", _selectedclass!);
                              //Navigator.push(context,MaterialPageRoute(builder: (context)=>ExamScreen()));
                            } else {
                              print("Err");
                            }
                          }
                        },
                        child: const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Text(
                            "Upload",
                            style: TextStyle(fontSize: 24),
                          ),
                        )),
                    const SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Future<String> upload(String title, String desc,classname) async {
    var res = await Dio().post("http://127.0.0.1:5000/api/upload/",
        data: FormData.fromMap(
            {"name": classname, "title": title, "desc": desc,'file': MultipartFile.fromBytes(_File as List<int>,filename: _FileName),}));
    print(res.data);
    return res.data["status"];
  }
}
