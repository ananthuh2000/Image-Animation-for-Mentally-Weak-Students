import 'dart:io';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ImportClassScreen extends StatefulWidget {
  @override
  _ImportClassScreenState createState() => _ImportClassScreenState();
}

class _ImportClassScreenState extends State<ImportClassScreen> {
  final _formKey = GlobalKey<FormState>();
  final _testNameController = TextEditingController();
  var _csvFile, _csvName;

  Future<void> _uploadData() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String email = pref.getString("email") ?? "";
    try {
      final response = await Dio().post(
        'http://127.0.0.1:5000/api/setStudents/',
        data: FormData.fromMap({
      "email": email,
      'name': _testNameController.text,
      'data': MultipartFile.fromBytes(_csvFile as List<int>,filename: _csvName),
    }),
      );

      print(response.data);
      Fluttertoast.showToast(msg: response.data["status"]);
      // handle the response
    } catch (error) {
      print(error);
    }
  }

  void _pickCsvFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['csv'],
    );
    print(result!.files.first.name);
    if (result != null) {
      setState(() {
        _csvFile = result.files.first.bytes;
        _csvName = result.files.first.name;
      });
    }
    setState(() {
      
    });
  }

  @override
  void dispose() {
    _testNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Class Name',
                  style: TextStyle(fontSize: 18.0),
                ),
                SizedBox(height: 8.0),
                TextFormField(
                  controller: _testNameController,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter a Class name';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    hintText: 'Enter Class name...',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 16.0),
                Text(
                  'Students CSV File',
                  style: TextStyle(fontSize: 18.0),
                ),
                SizedBox(height: 8.0),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        _csvFile != null ? _csvName : 'No file selected',
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    SizedBox(width: 8.0),
                    ElevatedButton(
                      onPressed: _pickCsvFile,
                      child: Text('Select File'),
                    ),
                  ],
                ),
                SizedBox(height: 8.0),
                Center(
                  child: ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate() &&
                          _csvFile != null) {
                        _uploadData();
                      }
                    },
                    child: Text('Submit'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
