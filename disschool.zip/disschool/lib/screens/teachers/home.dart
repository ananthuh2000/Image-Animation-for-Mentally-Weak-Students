import 'package:flutter/material.dart';

import '../login.dart';
import 'create_class.dart';
import 'upload_video.dart';

class DashBoardPage extends StatefulWidget {
  @override
  _DashBoardPageState createState() =>
      _DashBoardPageState();
}

class _DashBoardPageState extends State<DashBoardPage> {
  int _selectedIndex = 0;

  static List<Widget> _widgetOptions = <Widget>[
    ImportClassScreen(),
    UploadScreen()
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Teacher Dashboard'),
        actions: [
          IconButton(
              onPressed: () => Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (context) => Login())),
              icon: Icon(Icons.logout))
        ],
      ),
      body: Center(
        child: _widgetOptions.elementAt(_selectedIndex),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.assignment),
            label: 'Create Class',
          ),
          
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Add New Lecture',
          ),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}
