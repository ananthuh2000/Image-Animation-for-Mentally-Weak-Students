import 'package:flutter/material.dart';
import 'dart:io';

class Helper extends StatefulWidget {
  const Helper({super.key});

  @override
  State<Helper> createState() => _HelperState();
}

class _HelperState extends State<Helper> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: ElevatedButton(
        child: const Text("Click"),
        onPressed: () async {
          print("loading..");
          //"-i E:\\Client Work\\Ongoing\\real_time_img\\dist\\Inputs\\lal.jpg -c E:\\Client Work\\Ongoing\\real_time_img\\dist\\extract\\vox-adv-cpk.pth.tar"
          Process.run('E:\\Client Work\\Ongoing\\real_time_img\\dist\\image_animation.exe -i "E:\\Client Work\\Ongoing\\real_time_img\\dist\\Inputs\\lal.jpg" -c "E:\\Client Work\\Ongoing\\real_time_img\\dist\\extract\\vox-adv-cpk.pth.tar"', [],workingDirectory: "E:\\Client Work\\Ongoing\\real_time_img\\dist\\").then((result) {
            // stdout.write(result.stdout);
            // stderr.write(result.stderr);
            print(result.stderr.toString());
          });
        },
      )),
    );
  }
}
