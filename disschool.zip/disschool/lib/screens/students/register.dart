import 'package:disschool/network.dart';
import 'package:disschool/screens/login.dart';
import 'package:flutter/material.dart';
class Register extends StatefulWidget {
  const Register({super.key});

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final formKey = GlobalKey<FormState>();
  
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final passController = TextEditingController();
  final c_passController = TextEditingController();

  @override
  void dispose()
  {
    nameController.dispose();
    emailController.dispose();
    passController.dispose();
    c_passController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
           const Text("Register",style: TextStyle(fontSize: 40,fontWeight: FontWeight.bold),),
           Container(
            margin:const EdgeInsets.fromLTRB(0, 40, 0, 0),
            width: 500,
            child: Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TextFormField(
                    controller: nameController,
                    decoration:const InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Name")
                    ),
                    validator: (value) {
                      if(value == "")
                      {
                        return "Can't be empty";
                      }
                      else
                      {
                        return null;
                      }
                    },
                  ),
                  SizedBox(height: 10,),
                  TextFormField(
                    controller: emailController,
                    decoration:const InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Email")
                    ),
                    validator: (value) {
                      if(value == "")
                      {
                        return "Enter valid email";
                      }
                      else
                      {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    controller: passController,
                    obscureText: true,
                    decoration:const InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Password")
                    ),
                    validator: (value) {
                      if(value == "")
                      {
                        return "Enter valid password";
                      }
                      else
                      {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    controller: c_passController,
                    obscureText: true,
                    decoration:const InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Retype Password")
                    ),
                    validator: (value) {
                      if(value == "")
                      {
                        return "Enter valid password";
                      }
                      else if(value != passController.text)
                      {
                        return "Both password are not same";
                      }
                      else
                      {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  ElevatedButton(style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red
                  ),onPressed:() async{
                    if(formKey.currentState!.validate())
                    {
                      String status = await register(nameController.text, emailController.text, passController.text);

                      print(status);
                      if(status == "success")
                      {
                        Navigator.push(context, MaterialPageRoute(builder: (context)=> Login()));
                      }
                      else
                      {
                        print("err");
                      }
                    }
                  },
                  child: const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text("Register",style: TextStyle(fontSize: 24,fontWeight: FontWeight.w500),),
                  )),
                  const SizedBox(
                    height: 10,
                  ),
                  TextButton(onPressed: (){
                    Navigator.push(context,MaterialPageRoute(builder: (context)=>const Login()));
                  },
                  
                  child: const Text("Existing User? Click here to Login", style: TextStyle(color: Colors.red)))
                ],
              ),
            ),
           )
          ],
        ),
      ),
    );
  }
}