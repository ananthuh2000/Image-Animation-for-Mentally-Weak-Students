import 'package:flutter/material.dart';
import 'screens/login.dart';

void main() {
  runApp(const MaterialApp(home: Login()));
}