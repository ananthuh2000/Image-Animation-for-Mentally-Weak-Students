package com.example.disschool

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
