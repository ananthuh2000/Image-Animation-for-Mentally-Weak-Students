package com.example.students_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
