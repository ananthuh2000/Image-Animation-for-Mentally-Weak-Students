import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path/path.dart' as path;
import 'package:students_app/screens/login.dart';

class DashBoard extends StatefulWidget {
  @override
  _DashBoardState createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  List<Map<String, dynamic>> _data = [];
  String _character = "lal.jpg";
  String name = "";
  Future<void> fetchData() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    name = pref.getString("class") ?? "";
    try {
      final response = await Dio().post('http://127.0.0.1:5000/api/getVideos/',
          data: FormData.fromMap({"class": name}));
      setState(() {
        _data = List<Map<String, dynamic>>.from(response.data);
      });
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> downloadFile(String loc, String url) async {
    Dio dio = Dio();
    bool downloading = false;
    var progressString = "";
    String value;
    try {
      File file = File(url);
      String basename = path.basename(file.path);

      await dio.download(url, "$loc/$basename",
          onReceiveProgress: (rec, total) {
        print("Rec: $rec , Total: $total, Dir: $loc");
        setState(() {
          downloading = true;
          progressString = ((rec / total) * 100).toStringAsFixed(0) + "%";
        });
      });
    } catch (e) {
      print(e);
    }

    setState(() {
      downloading = false;
      progressString = "Completed";
    });
    print("Download completed");
  }

  @override
  Widget build(BuildContext context) {
    final columns = ['title', 'description', 'video'];
    return Scaffold(
      appBar: AppBar(
        title: Text('Student Classroom'),
        actions: [
          IconButton(onPressed: (){
            Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Login()));
          }, icon: Icon(Icons.logout))
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Expanded(
                      child: ListTile(
                        title: const Text('Mohanlal'),
                        leading: Radio<String>(
                          value: "lal.jpg",
                          groupValue: _character,
                          onChanged: (value) {
                            setState(() {
                              _character = value!;
                            });
                          },
                        ),
                      ),
                    ),
                    Expanded(
                      child: ListTile(
                        title: const Text('Monalisa'),
                        leading: Radio<String>(
                          value: "Monalisa.png",
                          groupValue: _character,
                          onChanged: (value) {
                            setState(() {
                              _character = value!;
                            });
                          },
                        ),
                      ),
                    ),
                    Expanded(
                      child: ListTile(
                        title: const Text('Mr. bean'),
                        leading: Radio<String>(
                          value: "bean.jpg",
                          groupValue: _character,
                          onChanged: (value) {
                            setState(() {
                              _character = value!;
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),
            Row(
              children: [
                Expanded(
                  child: DataTable(
                    columns: columns
                        .map((String col) => DataColumn(label: Text(col)))
                        .toList(),
                    rows: _data.map((Map<String, dynamic> row) {
                      return DataRow(
                        cells: columns
                            .map((String col) => DataCell((col == "video")
                                ? ElevatedButton(
                                    onPressed: () async {
                                      SharedPreferences pref =
                                          await SharedPreferences.getInstance();
                                      name = pref.getString("class") ?? "";
                                      downloadFile(
                                          "C:\\videos\\",
                                          "http://127.0.0.1:5000\\static\\files\\" +
                                              name +
                                              "\\" +
                                              row['video']);
                                              //-i .\\Inputs\\lal.png -c E:\\Client Work\\Ongoing\\real_time_img\\dist\\checkpoints\\vox-cpk.pth.tar -v C:\\videos\\'+row["video"]
                                      var result = await Process.run('E:\\Client Work\\Ongoing\\real_time_img\\dist\\image_animation.exe',['-c','extract\\vox-cpk.pth.tar','-i','Inputs\\'+_character,'-v','C:\\videos\\'+row['video']],workingDirectory: "E:\\Client Work\\Ongoing\\real_time_img\\dist\\");
                                      print(result.stderr.toString());
                                    },
                                    child: const Text("Open"))
                                : Text('${row[col]}')))
                            .toList(),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
