import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'dashboard.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final formKey = GlobalKey<FormState>();
  final emailController = TextEditingController();
  final passController = TextEditingController();
  List<String> _ClassNames = [];
  String? _selectedClass;

   void _fetchClassNames() async {
    try {
      final response = await Dio().post('http://127.0.0.1:5000/api/class/');
      for(var u in response.data)
      {
        _ClassNames.add(u["class_name"]);
      }
      setState(() {
        
      });
    } catch (e) {
      print(e);
    }
  }

  @override
  void dispose()
  {
    emailController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    _fetchClassNames();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
           const Text("Login",style: TextStyle(fontSize: 40,fontWeight: FontWeight.bold),),
           Container(
            margin:const EdgeInsets.fromLTRB(0, 40, 0, 0),
            width: 500,
            child: Form(
              key: formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  
                  TextFormField(
                    controller: emailController,
                    decoration:const InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Email")
                    ),
                    validator: (value) {
                      if(value == "")
                      {
                        return "Enter valid email";
                      }
                      else
                      {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    controller: passController,
                    obscureText: true,
                    decoration:const InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text("Password")
                    ),
                    validator: (value) {
                      if(value == "")
                      {
                        return "Enter valid password";
                      }
                      else
                      {
                        return null;
                      }
                    },
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  DropdownButtonFormField<String>(
      value: _selectedClass,
      decoration: InputDecoration(border: OutlineInputBorder()),
      hint: Text('Select an Class'),
      validator: (value) {
        if(value == null)
        {
          return "Can't be Empty";
        }
        return null;
      },
      onChanged: (value) {
        setState(() {
          _selectedClass = value;
        });
      },
      items: _ClassNames.map((ClassName) {
        return DropdownMenuItem<String>(
          value: ClassName,
          child: Text(ClassName),
        );
      }).toList(),
    ),
                  const SizedBox(
                    height: 10,
                  ),
                  ElevatedButton(onPressed:()async{
                    if(formKey.currentState!.validate())
                    {
                      String status = await login(emailController.text, passController.text,_selectedClass);
                      if(status == "success") {
                        SharedPreferences pref = await SharedPreferences.getInstance();
                        pref.setString("email", emailController.text);
                        pref.setString("class", _selectedClass!);
                        Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>DashBoard()));
                      } else {
                        print("Err");
                      }
                    }
                  },
                  child: const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text("Login",style: TextStyle(fontSize: 24),),
                  )),
                  const SizedBox(
                    height: 10,
                  ),
                  
                ],
              ),
            ),
           )
          ],
        ),
      ),
    );
  }

  Future<String> login(String email, String password,class_) async {
  var res = await Dio().post("http://127.0.0.1:5000/api/slogin/",
      data: FormData.fromMap({"email": email, "password": password,"class":class_}));
  print(res.data);
  return res.data["status"];
}
}